enyo.depends(
	'localStorage.js',
	'xhr.js',
	'Ajax.js',
	'Jsonp.js'
);