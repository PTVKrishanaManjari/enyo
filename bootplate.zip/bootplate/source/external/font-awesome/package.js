enyo.depends(
    "./css/font-awesome.css");