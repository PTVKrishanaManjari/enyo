function check(){
	var logindata=JSON.parse(localStorage.getItem("data"));
	var email=document.getElementById("email").value;
	var password=document.getElementById("password").value;
	var count=0;
	for(var i=0;i<=logindata.length;i++){
		if(email==logindata[i].email){
			if(password==logindata[i].pass){
				 count++;
				 break;
			}
		}
	}
	if(count==1){
		alert("login successful");
		document.getElementById("login").action="dashboard.html";
	
	}
	else{
		alert("invalid details");
	}
}