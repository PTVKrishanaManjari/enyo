JSON.stringify(localStorage.getItem("data"));
class elementcreation{
	constructor(selectdevice,devicename,devicelocation){
		this.selectdevice=selectdevice;
		this.devicename=devicename;
		this.devicelocation=devicelocation;
	}
}
function devicedatastoring(){
    var lights=[];
    var parkings=[];
    var bins=[];
	if(selectdevice=="Light"){
		var lights=JSON.parse(localStorage.getItem("light"));
		if(lights){
			lights.push(data);
			localStorage.setItem("light",JSON.stringify(lights));
		}
		else{
			lights=[];
			lights.push(data);
			localStorage.setItem("light",JSON.stringify(lights));
		}
	}
    else if(selectdevice=="Parking"){
        var parkings=JSON.parse(localStorage.getItem("parking"));
        if(parkings){
            parkings.push(data);
            localStorage.setItem("parking",JSON.stringify(parkings));
        }
        else{
            parkings=[];
            parkings.push(data);
            localStorage.setItem("parking",JSON.stringify(parkings));
        }
    }

    else if(selectdevice=="Bins"){
        var bins=JSON.parse(localStorage.getItem("bins"));
        if(bins){
            bins.push(data);
            localStorage.setItem("bins",JSON.stringify(bins));
        }
        else{
            bins=[];
            bins.push(data);
            localStorage.setItem("bins",JSON.stringify(bins));
        }
    }
    else{

    	alert("no data found");
    }

}
function create(){
	 selectdevice=document.getElementById("select").value;
	 devicename=document.getElementById("name").value;
	 devicelocation=document.getElementById("location").value;
	if(selectdevice=="" || devicename =="" || devicelocation==""){
		alert("please provide details");
	}
	else{
		data= new elementcreation(selectdevice,devicename,devicelocation);
		devicedatastoring();
	}
	
}