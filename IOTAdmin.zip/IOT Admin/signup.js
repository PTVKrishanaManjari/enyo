class userdata{
	constructor(name,email,pass){
		this.name=name;
		this.email=email;
		this.pass=pass;
	}
}
function getuserdata(){
	var users=[];
	users=JSON.parse(localStorage.getItem('data'));
	if(users)
	{
		users.push(data);
		localStorage.setItem('data',JSON.stringify(users));

	}
	else
	{
		users=[];
		users.push(data);
		localStorage.setItem('data',JSON.stringify(users));
	}


}
var validate=function(){
	let name=document.getElementById("name").value;
	let email=document.getElementById("email").value;
	let pass=document.getElementById("password").value;
	if(name=="" || email=="" || pass==""){
		alert("please fill out the fields");

	}	
	else{
		// var nameformat= /^[a-zA-Z]*$/;
		// var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		// var passwordformat= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/; 
		// if(!nameformat.match(name)){
		// 	alert("name must be in letters");
		// }
		// else if(!mailformat.match(email)){
		// 	alert("You have entered invalid email");
		// }
		// else if(!passwordformat.match(pass)){
		// 	alert("Your password must contain atleast one special character, one digit, one uppercase and one lowercase and lenth should between 8 to 15!")
		// }
		// else{
		// 	data=new userdata(name,email,pass);
		// 	getuserdata();
		// }
		data=new userdata(name,email,pass);
		getuserdata();
	}
}