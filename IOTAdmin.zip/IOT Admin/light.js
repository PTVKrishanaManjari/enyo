window.onload=function(){
var p=[];
p=JSON.parse(localStorage.getItem("light"));
var ul=document.getElementById("myUL");


	if(p)
	{
		for(i=0;i<p.length;i++)
		{
			var listItem=document.createElement("li");
			listItem.setAttribute("class","list");
			var p1=document.createElement("p");
			var p2=document.createElement("p");
			var p3=document.createElement("p");
			var deleteItem=document.createElement("button");
			deleteItem.id=i;
			deleteItem.innerHTML="delete";
			deleteItem.style.width="56px";
			deleteItem.style.height="30px";
			p1.innerHTML=p[i].selectdevice;
			p2.innerHTML=p[i].devicename;
			p3.innerHTML=p[i].devicelocation;
			deleteItem.addEventListener("click",remove);
			function remove(){
				var currentitem =event.target.id;
				var j=document.getElementById(currentitem);
				ul.removeChild(j);
				p.splice(currentitem,1);
				localStorage.setItem("light",JSON.stringify(p));
			}

			listItem.appendChild(p1);
			listItem.appendChild(p2);
			listItem.appendChild(p3);
			listItem.appendChild(deleteItem);
			listItem.id=i;
			ul.appendChild(listItem);
		}
	}

}